import {GET,POST} from '../../server/data';
export default async function handler(req:Request){
 if(!['GET','POST'].includes(req.method))return Response.json({error:'Método não permitido.'},{status:405,headers:{Allow:'GET, POST'}});
 try{return await (req.method==='GET'?GET(req):POST(req));}
 catch{return Response.json({error:'A agenda está temporariamente indisponível. Verifique a configuração do banco de dados no painel da hospedagem.'},{status:503});}
}
export const config={path:'/api/data'};
