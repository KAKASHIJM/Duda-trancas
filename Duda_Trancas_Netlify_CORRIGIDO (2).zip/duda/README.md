# Duda Tranças — publicação na Netlify

Projeto React + Vite, com página pública, painel em `/admin` e funções Netlify para agenda/admin.

## Publicar via GitHub (recomendado)

1. Extraia o ZIP e envie **o conteúdo da pasta** para a raiz de um repositório GitHub. `package.json`, `package-lock.json`, `netlify.toml` e `index.html` devem ficar na raiz.
2. Na Netlify, selecione **Add new site → Import an existing project** e conecte o repositório.
3. Use estas configurações:
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Node.js: `22` (já indicado em `netlify.toml`)
4. Para habilitar o painel e os agendamentos, configure em **Site configuration → Environment variables**:
   - `TURSO_DATABASE_URL`: URL do banco remoto Turso (`libsql://...`)
   - `TURSO_AUTH_TOKEN`: token do banco Turso
   - `ADMIN_KEY`: senha longa e exclusiva para administração
5. Faça um novo deploy depois de salvar as variáveis.
6. Teste a página inicial e `/admin`.

## Importante

- Não envie `node_modules` nem publique somente os arquivos-fonte por arrastar e soltar. Use deploy conectado ao Git para que a Netlify execute `npm run build` e publique `dist`, incluindo as funções.
- O site público pode abrir sem o banco configurado, mas as funções de agendamento e administração dependem das variáveis Turso.
- Nunca coloque tokens, senhas ou valores reais no código do navegador nem em variáveis `VITE_*`.
- Se o deploy falhar, abra **Deploys → deploy mais recente → Deploy log**. Se a página ficar branca depois de um deploy bem-sucedido, abra o site, pressione `F12` e consulte **Console**.

## Teste local

Requer Node.js 22.13+:

```bash
npm ci
npm test
npm run build
```

Para testar as funções localmente, use `npx netlify-cli dev` com as variáveis de ambiente configuradas. `npm run dev` inicia somente o Vite e não simula as Netlify Functions.
