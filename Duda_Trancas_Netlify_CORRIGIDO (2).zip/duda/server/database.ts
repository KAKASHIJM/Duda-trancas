import {createClient,type Client,type InValue} from '@libsql/client';
let client:Client|undefined;
let ready:Promise<unknown>|undefined;
async function database(){
 if(!client){
  const url=process.env.TURSO_DATABASE_URL;
  if(!url)throw new Error('DATABASE_NOT_CONFIGURED');
  if(process.env.NETLIFY && !/^(libsql|https):\/\//.test(url))throw new Error('REMOTE_DATABASE_REQUIRED');
  client=createClient({url,authToken:process.env.TURSO_AUTH_TOKEN});
 }
 if(!ready)ready=client.batch([
  'CREATE TABLE IF NOT EXISTS settings (id TEXT PRIMARY KEY, value TEXT NOT NULL)',
  'CREATE TABLE IF NOT EXISTS bookings (id TEXT PRIMARY KEY, token TEXT NOT NULL UNIQUE, name TEXT NOT NULL, phone TEXT NOT NULL, service INTEGER NOT NULL, date TEXT NOT NULL, start INTEGER NOT NULL, end INTEGER NOT NULL, status TEXT NOT NULL, notes TEXT NOT NULL)',
  'CREATE INDEX IF NOT EXISTS booking_availability ON bookings (date,status,start,end)'
 ],'write').catch(e=>{ready=undefined;throw e});
 await ready;return client;
}
function statement(sql:string,args:InValue[]=[]){
 const execute=async()=> (await database()).execute({sql,args});
 return {
  bind(...values:InValue[]){return statement(sql,values)},
  async first<T=Record<string,unknown>>():Promise<T|null>{const r=await execute();return (r.rows[0] as T|undefined)??null},
  async all(){const r=await execute();return {results:r.rows}},
  async run(){const r=await execute();return {meta:{changes:r.rowsAffected}}}
 };
}
export const env={DB:{prepare:statement},get ADMIN_KEY(){return process.env.ADMIN_KEY||''}};
