import React from 'react';
import { createRoot } from 'react-dom/client';
import Page from './app/page';
import Admin from './app/admin/page';
import './app/globals.css';

class AppErrorBoundary extends React.Component<React.PropsWithChildren, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error) { console.error('Erro ao renderizar o site Duda Tranças:', error); }
  render() {
    if (this.state.error) {
      return <main style={{minHeight:'100vh',display:'grid',placeItems:'center',padding:24,fontFamily:'system-ui,sans-serif',background:'#fff8f5',color:'#392b27'}}>
        <section style={{maxWidth:560,textAlign:'center'}}>
          <h1 style={{fontSize:28}}>Não foi possível carregar esta página</h1>
          <p>Atualize o site. Se o problema continuar, confira o Console do navegador e os logs do deploy na Netlify.</p>
          <button onClick={() => window.location.reload()} style={{padding:'12px 20px',border:0,borderRadius:8,background:'#7b3f35',color:'#fff',cursor:'pointer'}}>Tentar novamente</button>
        </section>
      </main>;
    }
    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  document.body.innerHTML = '<main style="font-family:system-ui;padding:2rem"><h1>Erro ao iniciar o site</h1><p>O elemento principal da página não foi encontrado. Confira o arquivo index.html.</p></main>';
} else {
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  const App = path === '/admin' ? Admin : Page;
  createRoot(rootElement).render(<React.StrictMode><AppErrorBoundary><App /></AppErrorBoundary></React.StrictMode>);
}
